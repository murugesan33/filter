import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl} from '@angular/forms';
import { ApiService, petDetails} from '../api.service';
import {Router} from '@angular/router';
import {HttpClient, HttpHeaders, HttpEventType} from '@angular/common/http';
import { tap } from 'rxjs/operators';
const URL = '../../assets/images/products';

@Component({
  selector: 'app-addpets',
  templateUrl: './addpets.component.html',
  styleUrls: ['./addpets.component.css'],
})
export class AddpetsComponent implements OnInit {
  
  addPetsForm: FormGroup;
  selectedFile:File = null;
  submitted = false;
  filterargs = {name: 'Toomy'};

  imgEx = false;
  imageName = '';
  previewUrl:any = null;
  petProdDet = [];
  editProd = {};
  title = "";
  action = null;
  petId = 0;
  actionBtn = 'Add'; 
  showProduct = true;

  
  constructor(private formBuilder:FormBuilder, private api : ApiService, private router : Router) { 
     if(!this.api.log.value){
      this.api.err.next("Please Login!");
      this.router.navigate(['login']);
     }else{
      this.api.err.next("");
     }
  }

/*positivenumber(ctrl:AbstractControl){
  if(parseInt(ctrl.value) < 0){
    return { positivenumber:true};
  }
  return null;
  
}*/
filterItem(val){
 this.filterargs.name=val
  console.log(val)
}

  ngOnInit() {
   // console.log("Hi");
      this.addPetsForm = this.formBuilder.group({
          petname : ['', Validators.required],
          petaddress : ['',Validators.required],
        //  petage : ['',[Validators.required,this.positivenumber]], //custom validation
         petage : ['',Validators.required],
          petgender : ['',Validators.required],
      })
      this.loadProducts();
      this.title = "Add Pet";
  }

  get petgender(){
    return this.addPetsForm.get('petgender');
  }

  get petage(){
    return this.addPetsForm.get('petage');
  }

  get petname(){
    return this.addPetsForm.get('petname');
  }

  get petaddress(){
    return this.addPetsForm.get('petaddress');
  }

  loadProducts(){
    this.api.getPetDetails().subscribe(data => this.petProdDet = data);
  }

  onSubmit(){
    this.submitted = true;
    if(this.addPetsForm.invalid || this.imgEx)
      return

  
      const petPOST = <petDetails> {
        userid: this.api.uId.value,
        name: this.addPetsForm.controls.petname.value,
        gender: this.addPetsForm.controls.petgender.value,
        age: this.addPetsForm.controls.petage.value,
        address: this.addPetsForm.controls.petaddress.value,
        // image: this.imageName
        image: this.previewUrl
      }  

      if(this.petId){
        //console.log(this.petId);
        petPOST.id = this.petId;
          this.api.updatePet(petPOST).subscribe((data) => {
           this.showProduct = true;
           //this.addPetsForm.reset();
           this.loadProducts();      
        });
     }else{
        this.api.setPetDetails(petPOST).subscribe((data) => {
          this.showProduct = true;
         // this.addPetsForm.reset();
          this.loadProducts();
        });
     }
     
  }

  onFileSelected(event){
    this.api.err.next('');
    let imgExt = ['jpeg','png','jpg'];
    this.selectedFile = <File>event.target.files[0];
   // console.log("image", this.selectedFile);
    const [img, ext] = this.selectedFile.type.split("/");
  //  console.log(img);
  //  console.log(ext);
   if(imgExt.indexOf(ext) == -1){
      this.imgEx = true;
      this.previewUrl = '';
    }else{
        var mimeType = this.selectedFile.type;
        if (mimeType.match(/image\/*/) == null) {
          return;
        }
        var reader = new FileReader();      
        reader.readAsDataURL(this.selectedFile); 
        reader.onload = (_event) => { 
        this.previewUrl = reader.result; 
       // console.log("url", this.previewUrl);
       }
      this.imgEx = false;
    }
    //console.log(this.selectedFile);
  }
  

  onUpload(){
    const fd = new FormData();
    fd.append('image',this.selectedFile, this.selectedFile.name);
    this.api.onUpload(fd).subscribe(data=>{
        console.log(fd);
        
      /*  if(data.type == HttpEventType.UploadProgress) {
            console.log('Upload progress: ', Math.round(data.loaded / data.total * 100) + '%');
        } else if(data.type === HttpEventType.Response) {
          console.log(data);
        } */
    });
  }

  editProduct(obj) {
    this.showProduct  = false;
    this.title = "Edit Pet";
    this.action = "edit"
    this.petId = obj.id;
    this.actionBtn = 'Update';
    this.addPetsForm.patchValue({
        petname : obj.name,
        petaddress : obj.address,
        petage : obj.age,
        petgender : obj.gender,
        image: obj.image
    })
  }

  addNewProducts(){
    this.addPetsForm.reset();
    this.showProduct  = false;
  }

  CancelAddProducts(){
    this.showProduct = true;
  }

}

