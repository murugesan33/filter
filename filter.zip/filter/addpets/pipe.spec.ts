import { MyFilterPipe } from './pipe';

// Isolated test case.
describe('MyFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new MyFilterPipe();
    const arr ={id:2}
    const arr1 =['olleh'];
    const mapData = {id:4, name:"murugesan",address:"4/405 Koil street"}
    expect(pipe).toBeTruthy();
    expect(pipe.transform(arr1,arr)).toBe('hello');
  });
});