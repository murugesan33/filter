import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddpetsComponent } from './addpets.component';
import { ApiService } from '../api.service';
import { MockApiService } from '../mocks/mock-api.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';
import {RouterTestingModule} from "@angular/router/testing";
import {Routes} from "@angular/router";
import { LoginComponent } from '../login/login.component';
import {AppModule} from '../app.module';
import { tap } from 'rxjs/operators';


describe('AddpetsComponent', () => {
  let component: AddpetsComponent;
  let fixture: ComponentFixture<AddpetsComponent>;
  
  const routes: Routes = [
    {path:'addpets',component: AddpetsComponent},
  ];

  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddpetsComponent, LoginComponent],
      imports: [HttpClientTestingModule, ReactiveFormsModule,RouterTestingModule.withRoutes(routes)],
    })
    .compileComponents();
  }));

 beforeEach(() => {
    fixture = TestBed.createComponent(AddpetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe(':', () => {

    function setup() {
      const sharedService = TestBed.get(ApiService);
      const httpTestingController = TestBed.get(HttpTestingController);
      return { sharedService, httpTestingController };
    }

    /*it('should be created', () => {
      const service: ApiService = TestBed.get(ApiService);
      expect(service).toBeTruthy();
    });*/

    it('should be created', () => {
      const { sharedService, httpTestingController } = setup();
      const mockGoogleMapData = {id: 1, country : 'United states of america', zipcode: '56743'};
      const arr = {id:2}
      sharedService.editProduct(arr).subscribe(data => {
        expect(data.mapData).toEqual(mockGoogleMapData);
      });

     

    /*  const req = httpTestingController.expectOne('http://localhost:3000/getUserDetails');

      expect(req.request.method).toBe('GET');

      req.flush({
        mapData: mockGoogleMapData
      });*/


    });

    afterEach(() => {
      const { httpTestingController } = setup();
      httpTestingController.verify();
    });
  });

 
});
